"use client"
import React from 'react'

const Page3 = () => {
    return (
        < >
 
        </>
    )
}
export default React.memo(Page3);