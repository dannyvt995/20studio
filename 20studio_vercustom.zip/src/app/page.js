"use client"

import HomePage from "./home";

export default function page() {


  return (
    <main>
      {/* <HomePage/> */}
    </main>
  );
}
