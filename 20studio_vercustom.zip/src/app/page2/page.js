"use client"
import React from 'react'
const Page2 = () => {
    return (
        < >
      
        </>
    )
}

export default React.memo(Page2);