import React from 'react'
import './style.css'
export default function page() {
  return (
    <div className='testFix'>
        <section className='section1'>
            Section1
        </section>
        <section className='section2'>
            Section2
        </section>
    </div>
  )
}
