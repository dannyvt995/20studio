export default function BackgroundFixed() {
    return(
        <section className="background_fixed_component" id="BACKGROUND_FIXED">
            <div className="for_section_wine_aboutus" id="ListWineSection"></div>
            <div className="for_section_stone_aboutus"  id="ListStoneSection"></div>
            <div className="for_section_form_contact_component"  id="FormContactSection"></div>
        </section>
    )
}